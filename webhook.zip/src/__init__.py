"""
Alertmanager Webhook for 企业微信
"""

